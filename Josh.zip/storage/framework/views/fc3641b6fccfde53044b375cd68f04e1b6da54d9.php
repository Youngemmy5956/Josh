<h2>Hello</h2> <br><br>
You have got an email from : <?php echo e($name); ?> <br><br>
User details: <br><br>
Name: <?php echo e($name); ?> <br>
Email: <?php echo e($email); ?> <br>
Subject: <?php echo e($subject); ?> <br>
Message: <?php echo e($messages); ?> <br><br>
Thanks
<?php /**PATH C:\Users\user\Josh\resources\views/mail.blade.php ENDPATH**/ ?>