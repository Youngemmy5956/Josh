<h2>Hello</h2> <br><br>
You have got an email from : {{ $name }} <br><br>
User details: <br><br>
Name: {{ $name }} <br>
Email: {{ $email }} <br>
Subject: {{ $subject }} <br>
Message: {{ $messages }} <br><br>
Thanks
